import React, { useState, useEffect, useMemo } from 'react';
import { 
  Grid3X3, 
  Search, 
  Save, 
  CheckCircle2, 
  AlertTriangle, 
  Layers, 
  FileSpreadsheet, 
  Download, 
  Upload, 
  RefreshCw, 
  Plus, 
  Info, 
  Filter, 
  Check, 
  X, 
  Factory, 
  Edit3, 
  Trash2, 
  Sliders, 
  Database,
  Copy,
  Zap,
  Wrench,
  RotateCcw
} from 'lucide-react';
import { ProductionLineId, LineActiveConfiguration, PartMaster } from '../types';
import { storageService } from '../services/storageService';
import { formatShots } from '../services/calculationService';
import { useLanguage } from '../i18n';

import { DeleteConfirmationModal } from '../components/common/DeleteConfirmationModal';
import { StageManagementModal } from '../components/common/StageManagementModal';
import { exportInstallMatrixExcel } from '../utils/excelExport';
import { DEFAULT_STAGE_GROUPS, deriveLogicalStage, sortStagesInOrder } from '../utils/stageUtils';

interface LineColDefinition {
  id: ProductionLineId;
  label: string;
  headerName: string;
  subName: string;
}

const LINE_COLUMNS: LineColDefinition[] = [
  { id: 'E1', label: 'E1', headerName: 'E1', subName: 'Ø7 Slit' },
  { id: 'E2', label: 'E2', headerName: 'E2', subName: 'Ø5 Slit' },
  { id: 'E3-1', label: 'E3-1', headerName: 'E3-1', subName: 'Slit 3P' },
  { id: 'E3-2', label: 'E3-2', headerName: 'E3-2', subName: 'WL+ 4P' },
  { id: 'E3-3', label: 'E3-3', headerName: 'E3-3', subName: 'New Cor 4P' },
  { id: 'E4', label: 'E4', headerName: 'E4', subName: 'Ø5 Slit' },
  { id: 'E5', label: 'E5', headerName: 'E5', subName: 'Ø5 Slit' },
];

interface StockQuantityMatrixViewProps {
  onNavigateToMaster?: () => void;
}

export const StockQuantityMatrixView: React.FC<StockQuantityMatrixViewProps> = ({
  onNavigateToMaster
}) => {
  const { language } = useLanguage();
  const [lines, setLines] = useState<LineActiveConfiguration[]>([]);
  const [partMasters, setPartMasters] = useState<PartMaster[]>([]);
  const [monitoringData, setMonitoringData] = useState<Record<string, any>>({});
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [selectedStageFilter, setSelectedStageFilter] = useState<string>('ALL');
  
  const [isEditing, setIsEditing] = useState(false);
  const [spareStocks, setSpareStocks] = useState<any[]>([]);
  const [editMatrixValues, setEditMatrixValues] = useState<Record<string, number>>({});
  const [editNoteValues, setEditNoteValues] = useState<Record<string, string>>({});
  const [editMinValues, setEditMinValues] = useState<Record<string, number>>({});
  const [editMaxValues, setEditMaxValues] = useState<Record<string, number>>({});
  const [editSafetyValues, setEditSafetyValues] = useState<Record<string, number>>({});
  const [saveSuccessMsg, setSaveSuccessMsg] = useState<string | null>(null);
  const [hasUnsavedChanges, setHasUnsavedChanges] = useState(false);

  // Inline Add State
  const [isAddingInline, setIsAddingInline] = useState(false);
  const [newRowData, setNewRowData] = useState<{
    stage: string;
    partName: string;
    partCode: string;
    quantities: Record<string, number>;
  }>({
    stage: DEFAULT_STAGE_GROUPS[0],
    partName: '',
    partCode: '',
    quantities: {
      'E1': 0,
      'E2': 0,
      'E3-1': 0,
      'E3-2': 0,
      'E3-3': 0,
      'E4': 0,
      'E5': 0,
    }
  });

  // CRUD Modals
  const [deleteTargetPart, setDeleteTargetPart] = useState<{ partCode: string; partName: string; stage: string; total: number } | null>(null);

  // Batch Update Modal / Panel State
  const [showBatchModal, setShowBatchModal] = useState(false);
  const [batchActionType, setBatchActionType] = useState<'FILL' | 'COPY' | 'RESET'>('FILL');
  const [batchTargetStage, setBatchTargetStage] = useState<string>('ALL');
  const [batchTargetLine, setBatchTargetLine] = useState<string>('ALL');
  const [batchFillQty, setBatchFillQty] = useState<number>(180);
  const [batchCopySourceLine, setBatchCopySourceLine] = useState<ProductionLineId>('E4');
  const [batchCopyTargetLine, setBatchCopyTargetLine] = useState<ProductionLineId>('E5');

  // Stage Grouping Manager Modal State
  const [isStageManagerOpen, setIsStageManagerOpen] = useState(false);

  const loadData = () => {
    setLines(storageService.getLineConfigs());
    setPartMasters(storageService.getPartMasters());
    setMonitoringData(storageService.getLinesMonitoring());
    setSpareStocks(storageService.getSpareStocks());
  };

  useEffect(() => {
    loadData();
    const unsub = storageService.subscribe(loadData);
    return () => unsub();
  }, []);

  const handleSaveNewRowInline = () => {
    if (!newRowData.partName.trim()) {
      alert('กรุณากรอก Part Name');
      return;
    }
    const finalPartCode = newRowData.partCode.trim() 
      ? newRowData.partCode.trim().toUpperCase() 
      : `P-${Date.now().toString().slice(-4)}`;

    const exists = partMasters.some(p => p.partCode.toUpperCase() === finalPartCode);
    if (exists) {
      alert(`รหัส Part Code "${finalPartCode}" มีอยู่ในระบบแล้ว กรุณาใช้รหัสอื่น`);
      return;
    }

    try {
      // 1. Save new Part Master
      const newPart: PartMaster = {
        partCode: finalPartCode,
        partName: newRowData.partName.trim(),
        partNameTh: newRowData.partName.trim(),
        stageName: newRowData.stage,
        description: `${newRowData.stage} Part`,
        category: 'PUNCH',
        unit: 'PCS',
        unitCostThb: 0,
        tubeSizeCompat: 'BOTH',
        drawingNumber: finalPartCode
      };
      storageService.savePartMaster(newPart);

      // 2. Save line quantities
      const currentConfigs = storageService.getLineConfigs();
      const updatedConfigs = currentConfigs.map(lineConfig => {
        const lineId = lineConfig.lineId;
        const qty = newRowData.quantities[lineId] || 0;
        return {
          ...lineConfig,
          stockQuantities: {
            ...(lineConfig.stockQuantities || {}),
            [finalPartCode]: qty
          }
        };
      });
      storageService.saveLineConfigs(updatedConfigs);

      // Reset and notify
      setIsAddingInline(false);
      setNewRowData({
        stage: stageOptions[0] || DEFAULT_STAGE_GROUPS[0],
        partName: '',
        partCode: '',
        quantities: {
          'E1': 0,
          'E2': 0,
          'E3-1': 0,
          'E3-2': 0,
          'E3-3': 0,
          'E4': 0,
          'E5': 0,
        }
      });
      loadData();
      setSaveSuccessMsg(`เพิ่มชิ้นส่วน "${newPart.partName}" (${finalPartCode}) สำเร็จแล้ว`);
      setTimeout(() => setSaveSuccessMsg(null), 4000);
    } catch (err: any) {
      alert(`เกิดข้อผิดพลาด: ${err.message}`);
    }
  };

  // Stage color badge style - Unified with PART INSTALL aesthetic
  const getStageColor = (stage: string) => {
    const stg = (stage || '').toUpperCase();
    
    // Define colors for standard stages
    if (stg.includes('PIERCE') || stg.includes('BURRING')) return 'border-[#FFCC00] text-[#FFCC00]'; // Yellow/Amber
    if (stg.includes('IRONING')) return 'border-blue-400 text-blue-400';
    if (stg.includes('LOUVER') || stg.includes('SLIT')) return 'border-emerald-400 text-emerald-400';
    if (stg.includes('REFLAIRE') || stg.includes('REFLARE')) return 'border-purple-400 text-purple-400';
    if (stg.includes('NOTCH') || stg.includes('PUNCH')) return 'border-sky-400 text-sky-400';
    if (stg.includes('CUT OFF') || stg.includes('SIDE CUT')) return 'border-rose-400 text-rose-400';
    if (stg.includes('FORMING')) return 'border-teal-400 text-teal-400';
    if (stg.includes('PILOT') || stg.includes('FEED')) return 'border-orange-400 text-orange-400';
    
    // Fallback for custom stages
    return 'border-slate-500 text-slate-300';
  };

  const getCellKey = (partCode: string, lineId: string) => `${partCode}__${lineId}`;

  // Unique list of stages for dropdown (combining custom stage groups and active stages)
  const stageOptions = useMemo(() => {
    const rawGroups = storageService.getStageGroups();
    const seen = new Set<string>();
    const uniqueList: string[] = [];

    // First add managed groups
    rawGroups.forEach(g => {
      const normalized = g.trim().toUpperCase();
      if (normalized && !seen.has(normalized)) {
        seen.add(normalized);
        uniqueList.push(g.trim());
      }
    });

    // Then add any stages from items that aren't in groups yet
    partMasters.forEach(pm => {
      const derived = pm.stageName || deriveLogicalStage(pm.partName, pm.stageName);
      if (derived && derived !== '-') {
        const normalized = derived.trim().toUpperCase();
        if (!seen.has(normalized)) {
          seen.add(normalized);
          uniqueList.push(derived.trim());
        }
      }
    });

    return sortStagesInOrder(uniqueList);
  }, [partMasters]);

  // Build the live matrix rows
  const matrixRows = useMemo(() => {
    return partMasters.map((pm, index) => {
      const stkItem = spareStocks.find(s => s.partCode === pm.partCode);
      const rowData: {
        no: number;
        partCode: string;
        partName: string;
        drawingCode: string;
        stageName: string;
        material?: string;
        maintenanceType?: 'REGRIND' | 'DISPOSE';
        quantities: Record<string, number>;
        installQuantities: Record<string, number>;
        total: number;
        stockNote: string;
        minimumStock: number;
        maximumStock: number;
        safetyStockQty: number;
      } = {
        no: index + 1,
        partCode: pm.partCode,
        partName: pm.partName,
        drawingCode: (pm as any).drawingNumber || pm.partCode,
        stageName: pm.stageName || deriveLogicalStage(pm.partName, pm.stageName),
        material: (pm as any).material || 'SKD11',
        maintenanceType: (pm as any).maintenanceType || 'REGRIND',
        quantities: {},
        installQuantities: {},
        total: 0,
        stockNote: pm.stockNote || (stkItem?.note || ''),
        minimumStock: stkItem?.minimumStock ?? 10,
        maximumStock: stkItem?.maximumStock ?? 50,
        safetyStockQty: stkItem?.safetyStockQty ?? (stkItem?.minimumStock ?? 10)
      };

      if (isEditing && editMinValues[pm.partCode] !== undefined) {
        rowData.minimumStock = editMinValues[pm.partCode];
      }
      if (isEditing && editMaxValues[pm.partCode] !== undefined) {
        rowData.maximumStock = editMaxValues[pm.partCode];
      }
      if (isEditing && editSafetyValues[pm.partCode] !== undefined) {
        rowData.safetyStockQty = editSafetyValues[pm.partCode];
      }
      if (isEditing && editNoteValues[pm.partCode] !== undefined) {
        rowData.stockNote = editNoteValues[pm.partCode];
      }

      let rowTotal = 0;
      LINE_COLUMNS.forEach(col => {
        let val = 0;
        let installVal = 0;
        const lineConfig = lines.find(l => l.lineId === col.id);
        if (lineConfig && lineConfig.stockQuantities) {
          val = lineConfig.stockQuantities[pm.partCode] || 0;
        }
        if (lineConfig && lineConfig.installedPartQuantities) {
          installVal = lineConfig.installedPartQuantities[pm.partCode] || 0;
        }
        
        rowData.installQuantities[col.id] = installVal;

        // If in edit mode and user modified this cell, reflect the edit value
        if (isEditing) {
          const key = getCellKey(pm.partCode, col.id);
          if (editMatrixValues[key] !== undefined) {
            val = editMatrixValues[key];
          }
        }

        rowData.quantities[col.id] = val;
        rowTotal += val;
      });

      rowData.total = rowTotal;
      return rowData;
    });
  }, [partMasters, lines, spareStocks, isEditing, editMatrixValues, editNoteValues, editMinValues, editMaxValues, editSafetyValues, monitoringData]);

  // Filtered rows
  const filteredRows = useMemo(() => {
    return matrixRows.filter(row => {
      const matchSearch = 
        row.partName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        row.partCode.toLowerCase().includes(searchTerm.toLowerCase()) ||
        row.drawingCode.toLowerCase().includes(searchTerm.toLowerCase()) ||
        row.stageName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        row.no.toString() === searchTerm.trim();

      if (!matchSearch) return false;

      if (selectedStageFilter !== 'ALL') {
        if (row.stageName.toUpperCase() !== selectedStageFilter.toUpperCase()) {
          return false;
        }
      }

      return true;
    });
  }, [matrixRows, searchTerm, selectedStageFilter]);

  // Grand totals across all lines
  const grandTotalActiveTooling = useMemo(() => {
    return matrixRows.reduce((sum, row) => sum + row.total, 0);
  }, [matrixRows]);

  const lineSubTotals = useMemo(() => {
    const totals: Record<string, number> = {};
    LINE_COLUMNS.forEach(col => {
      totals[col.id] = matrixRows.reduce((sum, row) => sum + (row.quantities[col.id] || 0), 0);
    });
    return totals;
  }, [matrixRows]);

  // Enter Edit Mode
  const handleStartEdit = () => {
    const currentValues: Record<string, number> = {};
    const currentMin: Record<string, number> = {};
    const currentMax: Record<string, number> = {};
    const currentSafety: Record<string, number> = {};
    const currentNote: Record<string, string> = {};

    matrixRows.forEach(row => {
      LINE_COLUMNS.forEach(col => {
        currentValues[getCellKey(row.partCode, col.id)] = row.quantities[col.id] || 0;
      });
      currentMin[row.partCode] = row.minimumStock;
      currentMax[row.partCode] = row.maximumStock;
      currentSafety[row.partCode] = row.safetyStockQty;
      currentNote[row.partCode] = row.stockNote;
    });

    setEditMatrixValues(currentValues);
    setEditMinValues(currentMin);
    setEditMaxValues(currentMax);
    setEditSafetyValues(currentSafety);
    setEditNoteValues(currentNote);
    setIsEditing(true);
    setHasUnsavedChanges(false);
  };

  // Cell Value Changed
  const handleCellChange = (partCode: string, lineId: string, val: number) => {
    const safeVal = Math.max(0, Math.floor(val || 0));
    setEditMatrixValues(prev => ({
      ...prev,
      [getCellKey(partCode, lineId)]: safeVal
    }));
    setHasUnsavedChanges(true);
  };

  // Cancel Edit Mode
  const handleCancelEdit = () => {
    if (hasUnsavedChanges) {
      if (!window.confirm('คุณมีการแก้ไขที่ยังไม่ได้บันทึก ต้องการยกเลิกใช่หรือไม่?')) {
        return;
      }
    }
    setIsEditing(false);
    setEditMatrixValues({});
    setEditMinValues({});
    setEditMaxValues({});
    setEditSafetyValues({});
    setEditNoteValues({});
    setHasUnsavedChanges(false);
  };

  // Apply Batch Update into Matrix Edit State
  const handleApplyBatchOperation = () => {
    let updatedValues: Record<string, number> = { ...editMatrixValues };
    if (!isEditing) {
      matrixRows.forEach(row => {
        LINE_COLUMNS.forEach(col => {
          updatedValues[getCellKey(row.partCode, col.id)] = row.quantities[col.id] || 0;
        });
      });
    }

    let affectedCount = 0;

    if (batchActionType === 'FILL') {
      matrixRows.forEach(row => {
        if (batchTargetStage === 'ALL' || row.stageName.toUpperCase() === batchTargetStage.toUpperCase()) {
          LINE_COLUMNS.forEach(col => {
            if (batchTargetLine === 'ALL' || col.id === batchTargetLine) {
              updatedValues[getCellKey(row.partCode, col.id)] = batchFillQty;
              affectedCount++;
            }
          });
        }
      });
    } else if (batchActionType === 'COPY') {
      matrixRows.forEach(row => {
        if (batchTargetStage === 'ALL' || row.stageName.toUpperCase() === batchTargetStage.toUpperCase()) {
          const sourceVal = updatedValues[getCellKey(row.partCode, batchCopySourceLine)] ?? row.quantities[batchCopySourceLine] ?? 0;
          updatedValues[getCellKey(row.partCode, batchCopyTargetLine)] = sourceVal;
          affectedCount++;
        }
      });
    } else if (batchActionType === 'RESET') {
      matrixRows.forEach(row => {
        if (batchTargetStage === 'ALL' || row.stageName.toUpperCase() === batchTargetStage.toUpperCase()) {
          LINE_COLUMNS.forEach(col => {
            if (batchTargetLine === 'ALL' || col.id === batchTargetLine) {
              updatedValues[getCellKey(row.partCode, col.id)] = 0;
              affectedCount++;
            }
          });
        }
      });
    }

    setEditMatrixValues(updatedValues);
    setIsEditing(true);
    setHasUnsavedChanges(true);
    setShowBatchModal(false);
    setSaveSuccessMsg(`ดำเนินการ Batch Update เสร็จสิ้น (${affectedCount} จุด) - กรุณากดบันทึกเพื่อยืนยัน`);
  };

  // Save All Changes to Database
  const handleSaveMatrix = () => {
    try {
      // 1. Perform validation for Min <= Max and Safety <= Max
      const keys = Object.keys(editMinValues);
      for (const pCode of keys) {
        const minVal = editMinValues[pCode];
        const maxVal = editMaxValues[pCode] !== undefined ? editMaxValues[pCode] : 9999;
        const safetyVal = editSafetyValues[pCode] !== undefined ? editSafetyValues[pCode] : 0;
        const pm = partMasters.find(p => p.partCode === pCode);
        const name = pm ? pm.partName : pCode;

        if (minVal < 0 || maxVal < 0 || safetyVal < 0) {
          alert(language === 'TH' ? 'ค่าสต็อกต้องไม่ติดลบ' : 'Stock values cannot be negative');
          return;
        }
        if (minVal > maxVal) {
          alert(language === 'TH' 
            ? `พาร์ท ${name}: ค่าสต็อกขั้นต่ำ (Min: ${minVal}) ต้องไม่มากกว่าสต็อกสูงสุด (Max: ${maxVal})` 
            : `Part ${name}: Min Stock (${minVal}) cannot be greater than Max Stock (${maxVal})`
          );
          return;
        }
        if (safetyVal > maxVal) {
          alert(language === 'TH' 
            ? `พาร์ท ${name}: ค่าสต็อกเพื่อความปลอดภัย (Safety: ${safetyVal}) ต้องไม่มากกว่าสต็อกสูงสุด (Max: ${maxVal})` 
            : `Part ${name}: Safety Stock (${safetyVal}) cannot be greater than Max Stock (${maxVal})`
          );
          return;
        }
      }

      const currentConfigs = storageService.getLineConfigs();
      const updatedConfigs = currentConfigs.map(lineConfig => {
        const lineId = lineConfig.lineId;
        const newQuantities: Record<string, number> = { ...(lineConfig.stockQuantities || {}) };

        partMasters.forEach(pm => {
          const key = getCellKey(pm.partCode, lineId);
          if (editMatrixValues[key] !== undefined) {
            newQuantities[pm.partCode] = editMatrixValues[key];
          }
        });

        return {
          ...lineConfig,
          stockQuantities: newQuantities
        };
      });

      storageService.saveLineConfigs(updatedConfigs);

      // Save Notes to PartMasters
      const updatedParts = partMasters.map(pm => {
        if (editNoteValues[pm.partCode] !== undefined) {
          return { ...pm, stockNote: editNoteValues[pm.partCode] };
        }
        return pm;
      });
      storageService.savePartMasters(updatedParts);

      // Save Stock limits to SpareStockItem
      const currentStocks = storageService.getSpareStocks();
      const updatedStocks = currentStocks.map(stk => {
        const pCode = stk.partCode;
        const minVal = editMinValues[pCode] !== undefined ? editMinValues[pCode] : stk.minimumStock;
        const maxVal = editMaxValues[pCode] !== undefined ? editMaxValues[pCode] : stk.maximumStock;
        const safetyVal = editSafetyValues[pCode] !== undefined ? editSafetyValues[pCode] : (stk.safetyStockQty ?? stk.minimumStock);
        const noteVal = editNoteValues[pCode] !== undefined ? editNoteValues[pCode] : (stk.note || '');

        // Sum up total stock quantity across all lines
        let totalQty = 0;
        LINE_COLUMNS.forEach(col => {
          const key = getCellKey(pCode, col.id);
          if (editMatrixValues[key] !== undefined) {
            totalQty += editMatrixValues[key];
          } else {
            const lineConfig = currentConfigs.find(l => l.lineId === col.id);
            if (lineConfig && lineConfig.stockQuantities) {
              totalQty += lineConfig.stockQuantities[pCode] || 0;
            }
          }
        });

        const reserved = stk.reservedQuantity || 0;
        const quarantine = stk.quarantineQuantity || 0;
        const available = Math.max(0, totalQty - reserved - quarantine);
        const requiredPerFull = stk.requiredQuantityPerFullReplacement || 1;

        let stockStatus: any = 'AVAILABLE';
        if (available === 0) stockStatus = 'NO_STOCK';
        else if (available < requiredPerFull) stockStatus = 'LOW_STOCK';
        else if (available <= minVal) stockStatus = 'MINIMUM';

        let combinedRisk: any = 'NORMAL';
        if (stk.hasDeliveryRisk) {
          combinedRisk = 'DELIVERY RISK';
        } else if (available === 0) {
          combinedRisk = 'STOP RISK';
        } else if (available < requiredPerFull) {
          combinedRisk = 'CRITICAL SUPPLY';
        } else if (available <= safetyVal) {
          combinedRisk = 'WARNING';
        }

        return {
          ...stk,
          onHandQuantity: totalQty,
          availableQuantity: available,
          minimumStock: minVal,
          maximumStock: maxVal,
          safetyStockQty: safetyVal,
          safetyStockMin: minVal,
          note: noteVal,
          stockStatus,
          combinedRisk
        };
      });

      storageService.saveSpareStocksList(updatedStocks);

      storageService.addAuditLog(
        'STOCK',
        `Batch updated Stock Matrix and safety limits across ${partMasters.length} parts and 7 lines`,
        `อัปเดตตารางจำนวนสต็อกและเกณฑ์ควบคุมความปลอดภัยเรียบร้อยแล้ว`
      );

      setIsEditing(false);
      setHasUnsavedChanges(false);
      setEditMatrixValues({});
      setEditMinValues({});
      setEditMaxValues({});
      setEditSafetyValues({});
      setEditNoteValues({});
      setSaveSuccessMsg(`บันทึกจำนวนสต็อกและเกณฑ์ความปลอดภัย ${partMasters.length} รายการสำเร็จแล้ว`);
      setTimeout(() => setSaveSuccessMsg(null), 4000);
      loadData();
    } catch (err: any) {
      alert(`เกิดข้อผิดพลาดในการบันทึก: ${err.message}`);
    }
  };

  // Delete Part
  const handleConfirmDelete = () => {
    if (!deleteTargetPart) return;
    try {
      storageService.deletePartMaster(deleteTargetPart.partCode);
      setSaveSuccessMsg(`ลบชิ้นส่วน ${deleteTargetPart.partName} (${deleteTargetPart.partCode}) เรียบร้อยแล้ว`);
      setDeleteTargetPart(null);
      loadData();
    } catch (err: any) {
      alert(`ลบไม่สำเร็จ: ${err.message}`);
    }
  };

  // Open Edit Modal for a row (navigate to Part Master tab)
  const handleOpenEditModalForRow = (row: typeof matrixRows[0]) => {
    if (onNavigateToMaster) {
      onNavigateToMaster();
    }
  };

  // Export Matrix to Excel (.xlsx)
  const handleExportCsv = () => {
    exportInstallMatrixExcel(matrixRows, LINE_COLUMNS);
  };

  return (
    <div className="space-y-3.5 font-sans text-white animate-fadeIn pb-8">
      
      {/* Note Options Datalist */}
      <datalist id="note-options">
        <option value="รอของเข้า (Waiting for PO)" />
        <option value="ของมีปัญหา/รอเคลม (Claim/Quarantine)" />
        <option value="ยืมจาก Line อื่น (Borrowed)" />
        <option value="ปรับปรุงสต็อก (Stock Adjusted)" />
        <option value="ส่งซ่อม (Sent for Repair)" />
      </datalist>

      {/* Alert Banner for Success */}
      {saveSuccessMsg && (
        <div className="bg-[#111111] border border-[#00FF00] text-[#00FF00] px-3 py-2 flex items-center justify-between shadow-lg">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-[#00FF00] flex-shrink-0" />
            <span className="text-xs font-mono font-bold">{saveSuccessMsg}</span>
          </div>
          <button onClick={() => setSaveSuccessMsg(null)} className="text-slate-400 hover:text-white cursor-pointer">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Search and Stage Selector Bar + Actions */}
      <div className="bg-[#111111] border border-[#666666] p-3 space-y-2.5 shadow-md mb-2">
        <div className="flex flex-col xl:flex-row items-stretch xl:items-center justify-between gap-3 pt-1">
          {/* Left Side: Filters & Search */}
          <div className="flex flex-wrap items-center gap-2.5 flex-1">
            {/* Stage Dropdown Filter & Manager Button */}
            <div className="flex items-center gap-1.5">
              <div className="flex items-center gap-1.5 bg-[#1a1a1a] border border-[#666666] px-2.5 py-1 text-xs min-w-[200px]">
                <Layers className="w-3.5 h-3.5 text-[#00FF00]" />
                <select
                  value={selectedStageFilter}
                  onChange={e => setSelectedStageFilter(e.target.value)}
                  className="bg-transparent text-[#00FF00] font-mono text-xs font-bold focus:outline-none cursor-pointer w-full"
                >
                  <option value="ALL" className="bg-[#111111] text-white">
                    {language === 'TH' ? 'ทุกสเตจ (All Stages)' : language === 'KO' ? '전체 스테이지 (All Stages)' : 'All Stages'}
                  </option>
                  {stageOptions.map(stage => (
                    <option key={stage} value={stage} className="bg-[#111111] text-white">
                      {stage}
                    </option>
                  ))}
                </select>
              </div>

              <button
                type="button"
                onClick={() => setIsStageManagerOpen(true)}
                className="px-2.5 py-1.5 bg-[#1a1a1a] hover:bg-[#252525] text-[#00FF00] border border-[#666666] text-xs font-bold rounded flex items-center gap-1 cursor-pointer transition-all whitespace-nowrap"
                title="เปิดหน้าต่างจัดกลุ่มและจัดการ Stage"
              >
                <Sliders className="w-3.5 h-3.5 text-[#00FF00]" />
                <span>⚙️ {language === 'TH' ? 'จัดกลุ่ม Stage' : language === 'KO' ? '스테이지 그룹 관리' : 'Group Stages'}</span>
              </button>
            </div>

            {/* Search Input */}
            <div className="relative w-full max-w-md">
              <Search className="absolute left-2.5 top-2.5 w-3.5 h-3.5 text-slate-400" />
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder={
                  language === 'TH'
                    ? 'ค้นหาชื่อชิ้นส่วน หรือ Stage...'
                    : language === 'KO'
                    ? '부품명 또는 스테이지 검색...'
                    : 'Search Part Name or Stage...'
                }
                className="w-full pl-8 pr-7 py-1.5 bg-[#1a1a1a] border border-[#666666] text-xs text-white placeholder-slate-500 font-mono focus:outline-none focus:border-[#00FF00]"
              />
              {searchTerm && (
                <button
                  type="button"
                  onClick={() => setSearchTerm('')}
                  className="absolute right-2 top-2 text-slate-400 hover:text-white cursor-pointer"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>
          </div>

          {/* Right Side: Action Buttons */}
          <div className="flex flex-wrap items-center gap-2 font-mono">
            <button
              type="button"
              onClick={() => setIsAddingInline(prev => !prev)}
              className={`px-3 py-1.5 text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer ${
                isAddingInline 
                  ? 'bg-amber-400 text-black font-extrabold shadow-md'
                  : 'bg-[#00FF00] hover:bg-[#00dd00] text-black'
              }`}
            >
              <Plus className="w-4 h-4" />
              <span>
                {language === 'TH'
                  ? '+ เพิ่มรายการใหม่ (Add Part Master)'
                  : language === 'KO'
                  ? '+ 새 부품 추가 (Add Part Master)'
                  : '+ Add Part Master'}
              </span>
            </button>

            {isEditing ? (
              <>
                <button
                  type="button"
                  onClick={handleCancelEdit}
                  className="px-3 py-1.5 bg-[#222222] hover:bg-[#333333] text-slate-300 text-xs font-bold border border-[#666666] flex items-center gap-1.5 transition-colors cursor-pointer"
                >
                  <X className="w-3.5 h-3.5" />
                  <span>ยกเลิก</span>
                </button>
                <button
                  type="button"
                  onClick={handleSaveMatrix}
                  className="px-4 py-1.5 bg-[#00FF00] hover:bg-[#00dd00] text-black font-black text-xs flex items-center gap-1.5 transition-colors cursor-pointer"
                >
                  <Save className="w-3.5 h-3.5" />
                  <span>บันทึกการแก้ไข ({hasUnsavedChanges ? 'มีการเปลี่ยนแปลง' : 'พร้อมบันทึก'})</span>
                </button>
              </>
            ) : (
              <>
                <button
                  type="button"
                  onClick={handleExportCsv}
                  className="px-3 py-1.5 bg-[#1a1a1a] hover:bg-[#262626] text-slate-300 border border-[#666666] text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer"
                >
                  <FileSpreadsheet className="w-3.5 h-3.5 text-[#00FF00]" />
                  <span>Export Excel (.xlsx)</span>
                </button>
                <button
                  type="button"
                  onClick={handleStartEdit}
                  className="px-3.5 py-1.5 bg-[#1a1a1a] hover:bg-[#262626] text-[#00FF00] border border-[#00FF00] font-black text-xs flex items-center gap-1.5 transition-colors cursor-pointer"
                >
                  <Edit3 className="w-3.5 h-3.5" />
                  <span>แก้ไขตัวเลขในตาราง (Edit Cells)</span>
                </button>
              </>
            )}
          </div>
        </div>
      </div>

      {/* ======================================================== */}
      {/* 2. INDUSTRIAL DATA TABLE WITH LOCKED STICKY HEADER */}
      {/* ======================================================== */}
      <div className="bg-[#111111] border border-[#666666] shadow-xl overflow-hidden">
        {/* Table Header Bar for Consistency */}
        <div className="p-2.5 bg-[#1a1a1a] border-b border-[#666666] flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <Layers className="w-4 h-4 text-[#00FF00]" />
            <span className="text-xs font-bold text-white font-mono uppercase tracking-wider">
              INSTALLED QUANTITY MATRIX ({matrixRows.length} รายการ)
            </span>
          </div>
          <div className="flex items-center gap-3 text-[11px] text-slate-400 font-mono">
            <span className="flex items-center gap-1">
              <span className="w-2 h-2 rounded-full bg-[#00FF00]"></span>
              <span>หัวตารางล็อกคงที่ (Locked Sticky Header)</span>
            </span>
          </div>
        </div>
        {/* Scrollable Container with Sticky Table Headers */}
        <div className="overflow-x-auto overflow-y-auto max-h-[calc(100vh-270px)] scrollbar-thin relative">
          <table 
            className="w-full text-left text-xs font-mono min-w-full" 
            style={{ borderCollapse: 'separate', borderSpacing: 0 }}
          >
            {/* Top Multi-Header Row (Locked at top) */}
            <thead>
              {/* Row 1 Header: Main Divisions (Sticky top-0) */}
              <tr className="text-white select-none">
                <th 
                  colSpan={3} 
                  className="sticky top-0 z-20 bg-[#444455] text-white font-black py-1.5 px-1.5 border-b border-r border-[#666666] text-left uppercase tracking-wider text-[11px] shadow-xs"
                >
                  1. PART IDENTIFICATION
                </th>
                <th 
                  colSpan={8} 
                  className="sticky top-0 z-20 bg-[#2a3a2a] text-[#00FF7F] font-black py-1.5 px-1.5 border-b border-r border-[#666666] text-center uppercase tracking-wider text-[11px] shadow-xs"
                >
                  2. STOCK QUANTITY BY LINE (EA)
                </th>
                <th 
                  colSpan={2} 
                  className="sticky top-0 z-20 bg-[#2d3a4a] text-cyan-300 font-black py-1.5 px-1.5 border-b border-r border-[#666666] text-center uppercase tracking-wider text-[11px] shadow-xs"
                >
                  3. SAFETY STOCK & STATUS (IDEA 6)
                </th>
                <th 
                  colSpan={2} 
                  className="sticky top-0 z-20 bg-[#444455] text-[#FFCC00] font-black py-1.5 px-1.5 border-b border-[#666666] text-center uppercase tracking-wider text-[11px] shadow-xs w-32"
                >
                  4. REMARKS & ACTIONS
                </th>
              </tr>

              {/* Sub Columns Header: Row 2 (Sticky top-27px) */}
              <tr className="text-white font-bold text-[10px] select-none">
                {/* Col: No */}
                <th className="sticky top-[27px] z-20 py-1 px-1 w-8 text-center border-b border-r border-[#666666] bg-[#555566]">
                  No
                </th>

                {/* Col: Stage */}
                <th className="sticky top-[27px] z-20 py-1 px-1 min-w-[140px] w-36 text-center border-b border-r border-[#666666] bg-[#555566]">
                  Stage
                </th>

                {/* Col: Part Name */}
                <th className="sticky top-[27px] z-20 py-1 px-1 min-w-[120px] text-left border-b border-r border-[#666666] bg-[#555566]">
                  Part Name
                </th>

                {/* Col: E1 */}
                <th className="sticky top-[27px] z-20 py-0.5 px-0.5 text-center border-b border-r border-[#666666] bg-[#3a4a3a] text-[#00FF7F]">
                  <div className="font-bold text-white text-[11px]">E1</div>
                  <div className="text-[8px] text-slate-300 font-normal leading-tight">Ø7 Slit</div>
                </th>

                {/* Col: E2 */}
                <th className="sticky top-[27px] z-20 py-0.5 px-0.5 text-center border-b border-r border-[#666666] bg-[#3a4a3a] text-[#00FF7F]">
                  <div className="font-bold text-white text-[11px]">E2</div>
                  <div className="text-[8px] text-slate-300 font-normal leading-tight">Ø5 Slit</div>
                </th>

                {/* Col: E3-1 */}
                <th className="sticky top-[27px] z-20 py-0.5 px-0.5 text-center border-b border-r border-[#666666] bg-[#3a4a3a] text-[#00FF7F]">
                  <div className="font-bold text-white text-[11px]">E3-1</div>
                  <div className="text-[8px] text-slate-300 font-normal leading-tight">Slit 3P</div>
                </th>

                {/* Col: E3-2 */}
                <th className="sticky top-[27px] z-20 py-0.5 px-0.5 text-center border-b border-r border-[#666666] bg-[#3a4a3a] text-[#00FF7F]">
                  <div className="font-bold text-white text-[11px]">E3-2</div>
                  <div className="text-[8px] text-slate-300 font-normal leading-tight">WL+ 4P</div>
                </th>

                {/* Col: E3-3 */}
                <th className="sticky top-[27px] z-20 py-0.5 px-0.5 text-center border-b border-r border-[#666666] bg-[#3a4a3a] text-[#00FF7F]">
                  <div className="font-bold text-white text-[11px]">E3-3</div>
                  <div className="text-[8px] text-slate-300 font-normal leading-tight">New Cor 4P</div>
                </th>

                {/* Col: E4 */}
                <th className="sticky top-[27px] z-20 py-0.5 px-0.5 text-center border-b border-r border-[#666666] bg-[#3a4a3a] text-[#00FF7F]">
                  <div className="font-bold text-white text-[11px]">E4</div>
                  <div className="text-[8px] text-slate-300 font-normal leading-tight">Ø5 Slit</div>
                </th>

                {/* Col: E5 */}
                <th className="sticky top-[27px] z-20 py-0.5 px-0.5 text-center border-b border-r border-[#666666] bg-[#3a4a3a] text-[#00FF7F]">
                  <div className="font-bold text-white text-[11px]">E5</div>
                  <div className="text-[8px] text-slate-300 font-normal leading-tight">Ø5 Slit</div>
                </th>

                {/* Col: Total */}
                <th className="sticky top-[27px] z-20 py-1 px-1 w-14 text-center bg-[#444455] text-[#FFCC00] font-bold border-b border-r border-[#666666]">
                  Total
                </th>

                {/* Col: Safety Stock Level (Idea 6) */}
                <th className="sticky top-[27px] z-20 py-1 px-1 w-20 text-center bg-[#3a4a58] text-cyan-300 font-bold border-b border-r border-[#666666]">
                  <div>Safety Stock</div>
                  <div className="text-[8px] text-slate-300 font-normal">เกณฑ์สำรอง</div>
                </th>

                {/* Col: Stock Status (Idea 6) */}
                <th className="sticky top-[27px] z-20 py-1 px-1 w-24 text-center bg-[#3a4a58] text-cyan-300 font-bold border-b border-r border-[#666666]">
                  <div>Stock Status</div>
                  <div className="text-[8px] text-slate-300 font-normal">สถานะสต็อก</div>
                </th>

                {/* Col: Notes */}
                <th className="sticky top-[27px] z-20 py-1 px-1 min-w-[150px] text-left bg-[#444455] text-white font-bold border-b border-r border-[#666666]">
                  Notes / Remarks
                </th>

                {/* Col: Actions */}
                <th className="sticky top-[27px] z-20 py-1 px-1 w-16 text-center bg-[#444455] text-[#FFCC00] font-bold border-b border-[#666666]">
                  Actions
                </th>
              </tr>
            </thead>

            {/* Table Rows Body */}
            <tbody>
              {/* TOP INLINE ADD ROW (Direct Entry at Top of Table - No Popup) */}
              {isAddingInline && (
                <tr className="bg-[#1e2e1e] border-b-2 border-[#00FF00] animate-fadeIn">
                  <td className="py-1 px-2 text-center text-[#00FF00] font-bold border-r border-[#444444]">
                    NEW
                  </td>
                  <td className="py-1 px-1 border-r border-[#444444]">
                    <select
                      value={newRowData.stage}
                      onChange={e => setNewRowData({ ...newRowData, stage: e.target.value })}
                      className="w-full bg-[#111111] text-[#00FF00] border border-[#00FF00] p-1 text-[11px] font-bold font-mono focus:outline-none"
                    >
                      {stageOptions.length > 0 ? (
                        stageOptions.map(stg => (
                          <option key={stg} value={stg} className="bg-[#111111] text-white">
                            {stg}
                          </option>
                        ))
                      ) : (
                        <option value="Stage 1: Piercing & Burring">Stage 1: Piercing & Burring</option>
                      )}
                    </select>
                  </td>
                  <td className="py-1 px-1 border-r border-[#444444]">
                    <input
                      type="text"
                      placeholder="Part Name (e.g. Louver Punch)"
                      value={newRowData.partName}
                      onChange={e => setNewRowData({ ...newRowData, partName: e.target.value })}
                      className="w-full bg-[#111111] text-white border border-[#00FF00] px-1.5 py-0.5 text-xs font-bold font-mono focus:outline-none"
                    />
                  </td>
                  {LINE_COLUMNS.map(col => (
                    <td key={col.id} className="py-1 px-1 border-r border-[#444444]">
                      <input
                        type="number"
                        min="0"
                        value={newRowData.quantities[col.id] || ''}
                        onChange={e => {
                          const val = parseInt(e.target.value) || 0;
                          setNewRowData({
                            ...newRowData,
                            quantities: {
                              ...newRowData.quantities,
                              [col.id]: val
                            }
                          });
                        }}
                        className="w-full bg-[#111111] text-center text-[#00FF00] border border-[#666666] py-0.5 text-xs font-mono font-bold"
                      />
                    </td>
                  ))}
                  <td className="py-1 px-2 text-center text-[#FFCC00] font-bold border-r border-[#444444]">
                    {(Object.values(newRowData.quantities) as number[]).reduce((a, b) => (Number(a) || 0) + (Number(b) || 0), 0)}
                  </td>
                  <td className="py-1 px-1 text-center bg-[#151d24] border-r border-[#444444]">
                    <span className="text-[10px] text-cyan-300 font-mono">10 EA</span>
                  </td>
                  <td className="py-1 px-1 text-center bg-[#151d24] border-r border-[#444444]">
                    <span className="text-[10px] text-slate-400">NEW</span>
                  </td>
                  <td className="py-1 px-2 border-r border-[#444444] bg-[#1a1a1a]">
                    <span className="text-[10px] text-slate-500">-</span>
                  </td>
                  <td className="py-1 px-2 text-center border-[#444444] bg-[#182818]">
                    <div className="flex items-center justify-center gap-1">
                      <button
                        type="button"
                        onClick={handleSaveNewRowInline}
                        className="px-2 py-0.5 bg-[#00FF00] hover:bg-[#00dd00] text-black font-bold text-[11px] rounded flex items-center gap-0.5 cursor-pointer shadow-sm"
                        title="บันทึกรายการใหม่"
                      >
                        <Check className="w-3.5 h-3.5" />
                        <span>บันทึก</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => setIsAddingInline(false)}
                        className="p-1 bg-[#222222] hover:bg-[#333333] text-rose-400 rounded border border-[#666666] cursor-pointer"
                        title="ยกเลิก"
                      >
                        <X className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </td>
                </tr>
              )}

              {/* ======================================================== */}
              {filteredRows.length === 0 && !isAddingInline ? (
                <tr>
                  <td colSpan={12} className="py-8 text-center text-slate-500 bg-[#161616] border-b border-[#666666]">
                    ไม่พบรายการชิ้นส่วนที่ตรงกับคำค้นหา "{searchTerm}"
                  </td>
                </tr>
              ) : (
                filteredRows.map((row) => {
                  const isOutOfStock = row.total === 0;
                  const isBelowSafety = row.total <= row.safetyStockQty;
                  let rowBgClass = "bg-[#1e1e1e] hover:bg-[#282828]";
                  if (isOutOfStock) {
                    rowBgClass = "bg-[#331118] hover:bg-[#3d1921] transition-all";
                  } else if (isBelowSafety) {
                    rowBgClass = "bg-[#2e2211] hover:bg-[#382b18] transition-all";
                  }

                  return (
                    <tr 
                      key={row.partCode} 
                      className={`${rowBgClass} border-b border-[#444444]`}
                    >
                      {/* Col 1: No */}
                      <td className="py-1 px-2 text-center text-slate-400 font-bold border-r border-[#444444]">
                        {row.no}
                      </td>

                      {/* Col 2: Stage */}
                      <td className="py-1 px-2 text-center border-r border-[#444444]">
                        <span className={`inline-block px-1.5 py-0.5 text-[10px] font-bold border bg-[#111111] uppercase ${getStageColor(row.stageName)}`}>
                          {row.stageName}
                        </span>
                      </td>

                      {/* Col 3: Part Name */}
                      <td className="py-1 px-2 text-left border-r border-[#444444]">
                        <div>
                          <span className="font-bold text-white text-xs uppercase hover:text-[#00FF00] transition-colors block">
                            {row.partName}
                          </span>
                          
                          {isEditing ? (
                            <div className="flex flex-col gap-1 mt-1.5 p-1 bg-[#111111] rounded border border-[#333333] max-w-[190px]">
                              <div className="flex items-center justify-between gap-1 text-[10px] font-mono">
                                <span className="text-amber-400 font-bold">Safety:</span>
                                <input
                                  type="number"
                                  min={0}
                                  value={row.safetyStockQty}
                                  onChange={(e) => {
                                    const val = Math.max(0, parseInt(e.target.value, 10) || 0);
                                    setEditSafetyValues(prev => ({
                                      ...prev,
                                      [row.partCode]: val
                                    }));
                                    setHasUnsavedChanges(true);
                                  }}
                                  className="w-14 bg-[#1e1e1e] border border-[#555555] text-amber-300 text-center text-[10px] py-0.5 focus:border-amber-400 focus:outline-none font-bold"
                                />
                              </div>
                              <div className="flex items-center justify-between gap-1 text-[10px] font-mono">
                                <span className="text-slate-300 font-bold">Min:</span>
                                <input
                                  type="number"
                                  min={0}
                                  value={row.minimumStock}
                                  onChange={(e) => {
                                    const val = Math.max(0, parseInt(e.target.value, 10) || 0);
                                    setEditMinValues(prev => ({
                                      ...prev,
                                      [row.partCode]: val
                                    }));
                                    setHasUnsavedChanges(true);
                                  }}
                                  className="w-14 bg-[#1e1e1e] border border-[#555555] text-slate-300 text-center text-[10px] py-0.5 focus:border-cyan-400 focus:outline-none font-bold"
                                />
                              </div>
                              <div className="flex items-center justify-between gap-1 text-[10px] font-mono">
                                <span className="text-slate-300 font-bold">Max:</span>
                                <input
                                  type="number"
                                  min={0}
                                  value={row.maximumStock}
                                  onChange={(e) => {
                                    const val = Math.max(0, parseInt(e.target.value, 10) || 0);
                                    setEditMaxValues(prev => ({
                                      ...prev,
                                      [row.partCode]: val
                                    }));
                                    setHasUnsavedChanges(true);
                                  }}
                                  className="w-14 bg-[#1e1e1e] border border-[#555555] text-slate-300 text-center text-[10px] py-0.5 focus:border-cyan-400 focus:outline-none font-bold"
                                />
                              </div>
                            </div>
                          ) : (
                            <div className="flex items-center gap-1.5 mt-1 font-mono text-[10px]">
                              <span className={`px-1 py-0.5 rounded text-[9px] font-bold ${
                                row.total === 0 
                                  ? 'bg-red-950 text-red-400 border border-red-800' 
                                  : row.total <= row.safetyStockQty 
                                    ? 'bg-amber-950/80 text-amber-400 border border-amber-800/80 animate-pulse' 
                                    : 'bg-[#161b22] text-slate-400 border border-[#30363d]'
                              }`}>
                                Safety: {row.safetyStockQty}
                              </span>
                              <span className="text-slate-600">|</span>
                              <span className="text-slate-400">Min: {row.minimumStock}</span>
                              <span className="text-slate-600">|</span>
                              <span className="text-slate-400">Max: {row.maximumStock}</span>
                            </div>
                          )}
                        </div>
                      </td>

                      {/* Col 4 - 10: E1 to E5 Line Quantities */}
                      {LINE_COLUMNS.map(col => {
                        const qty = row.quantities[col.id] || 0;
                        const installVal = row.installQuantities[col.id] || 0;
                        
                        // Check Predictive Demand (Is this part about to expire on this line?)
                        let isHighRisk = false;
                        let usagePct = 0;
                        if (monitoringData && monitoringData[col.id]) {
                           const liveItems = monitoringData[col.id].items || [];
                           const liveItem = liveItems.find((i: any) => i.partCode === row.partCode);
                           if (liveItem) {
                              usagePct = liveItem.usagePercent || 0;
                              if (usagePct >= 90) {
                                 isHighRisk = true;
                              }
                           }
                        }

                        // Calculate Alert Status
                        let statusColor = 'text-slate-500 bg-[#1a1a1a] border-[#555555]'; // None
                        let alertTitle = `ต้องการติดตั้ง: ${installVal} ชิ้น`;

                        if (installVal > 0) {
                          if (qty === 0) {
                            statusColor = 'text-white bg-[#C40045] border-red-500 animate-pulse'; // Critical
                            alertTitle = `วิกฤต! สต็อก 0 ชิ้น (ต้องการติดตั้ง: ${installVal} ชิ้น)`;
                          } else if (qty < installVal) {
                            statusColor = 'text-black bg-[#FFCC00] border-yellow-500'; // Warning
                            alertTitle = `แจ้งเตือน: สต็อกไม่พอเปลี่ยนยกชุด (มี: ${qty} / ต้องการ: ${installVal})`;
                          } else if (isHighRisk) {
                            statusColor = 'text-white bg-[#FF6600] border-[#FF9900] animate-pulse'; // Predictive Demand Risk
                            alertTitle = `แจ้งเตือนล่วงหน้า! อะไหล่บน Line ${col.id} ถูกใช้งานไปแล้ว ${usagePct.toFixed(0)}% กำลังจะต้องเปลี่ยนเร็วๆ นี้`;
                          } else {
                            statusColor = 'text-[#00FF00] bg-[#111111] border-[#00FF00]'; // Safe
                            alertTitle = `ปลอดภัย: สต็อกมีเพียงพอ (มี: ${qty} / ต้องการ: ${installVal})`;
                          }
                        } else if (qty > 0) {
                           statusColor = 'text-[#00FF7F] bg-[#111111] border-[#00FF7F]'; // Has stock but no install
                        }

                        // Determine Text Color for View Mode
                        let viewTextColor = 'text-slate-500';
                        if (installVal > 0) {
                          if (qty === 0) viewTextColor = 'text-[#C40045]';
                          else if (qty < installVal) viewTextColor = 'text-[#FFCC00]';
                          else if (isHighRisk) viewTextColor = 'text-[#FF9900]';
                          else viewTextColor = 'text-[#00FF00]';
                        } else if (qty > 0) {
                           viewTextColor = 'text-[#00FF7F]';
                        }

                        // Highlight background in View Mode if critical or warning
                        let viewBg = '';
                        if (!isEditing && installVal > 0) {
                           if (qty === 0) viewBg = 'bg-[#400016] animate-pulse';
                           else if (qty < installVal) viewBg = 'bg-[#332800]';
                           else if (isHighRisk) viewBg = 'bg-[#4a1c00] animate-pulse';
                        }

                        return (
                          <td 
                            key={col.id} 
                            className={`py-1 px-0.5 text-center border-r border-[#444444] font-mono transition-colors ${viewBg}`}
                            title={!isEditing ? alertTitle : undefined}
                          >
                            {isEditing ? (
                              <input
                                type="number"
                                min={0}
                                max={9999}
                                value={qty === 0 ? '' : qty}
                                placeholder="-"
                                onChange={(e) => {
                                  const val = e.target.value === '' ? 0 : parseInt(e.target.value, 10) || 0;
                                  handleCellChange(row.partCode, col.id, val);
                                }}
                                className={`w-full py-0.5 text-center text-xs font-bold border focus:outline-none ${statusColor}`}
                                title={alertTitle}
                              />
                            ) : (
                              <span 
                                className={`font-bold text-xs ${viewTextColor} ${qty > 0 || installVal > 0 ? 'font-black' : ''}`}
                              >
                                {qty > 0 ? qty : '-'}
                              </span>
                            )}
                          </td>
                        );
                      })}

                      {/* Col 11: Row Total */}
                      <td className="py-1 px-2 text-center bg-[#181818] border-r border-[#444444]">
                        <span className={`text-xs font-black font-mono ${row.total > 0 ? 'text-[#FFCC00]' : 'text-slate-500'}`}>
                          {row.total > 0 ? row.total : 0}
                        </span>
                      </td>

                      {/* Col: Safety Stock Target (Idea 6) */}
                      <td className="py-1 px-1 text-center bg-[#151d24] border-r border-[#444444]">
                        {isEditing ? (
                          <input
                            type="number"
                            min={0}
                            value={row.safetyStockQty}
                            onChange={(e) => {
                              const val = parseInt(e.target.value, 10) || 0;
                              setEditSafetyValues(prev => ({ ...prev, [row.partCode]: val }));
                              setHasUnsavedChanges(true);
                            }}
                            className="w-14 py-0.5 text-center text-xs font-bold border border-cyan-500 bg-[#111111] text-cyan-300 focus:outline-none"
                            title="กำหนดระดับ Safety Stock (ชิ้น)"
                          />
                        ) : (
                          <span className="text-xs font-mono text-cyan-300 font-bold">
                            {row.safetyStockQty} EA
                          </span>
                        )}
                      </td>

                      {/* Col: Stock Health Status Badge (Idea 6) */}
                      <td className="py-1 px-1 text-center bg-[#151d24] border-r border-[#444444]">
                        {(() => {
                          const totalInstalled = (Object.values(row.installQuantities) as number[]).reduce((a, b) => (Number(a) || 0) + (Number(b) || 0), 0);
                          if (totalInstalled === 0 && row.total === 0) {
                            return <span className="text-[10px] text-slate-500 font-bold">STANDBY</span>;
                          }
                          if (row.total === 0 && totalInstalled > 0) {
                            return (
                              <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[10px] font-black bg-[#C40045] text-white animate-pulse" title={`สต็อกหมดเกลี้ยง! มีการติดตั้งใช้งาน ${totalInstalled} ชิ้น เสี่ยงไลน์หยุดผลิต`}>
                                <AlertTriangle className="w-3 h-3" />
                                OUT
                              </span>
                            );
                          }
                          if (row.total < row.safetyStockQty) {
                            return (
                              <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[10px] font-black bg-[#FFCC00] text-black" title={`ต่ำกว่า Safety Stock (${row.total} / ${row.safetyStockQty} EA)`}>
                                <AlertTriangle className="w-3 h-3" />
                                LOW
                              </span>
                            );
                          }
                          return (
                            <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[10px] font-bold bg-[#00FF00]/20 text-[#00FF00] border border-[#00FF00]/40" title="สต็อกเพียงพอตามเกณฑ์ความปลอดภัย">
                              <CheckCircle2 className="w-3 h-3" />
                              OK
                            </span>
                          );
                        })()}
                      </td>

                      {/* Col 12: Notes / Remarks */}
                      <td className="py-1 px-2 text-left bg-[#1a1a1a] border-r border-[#444444]">
                        {isEditing ? (
                          <input
                            type="text"
                            value={row.stockNote}
                            onChange={(e) => {
                              setEditNoteValues(prev => ({
                                ...prev,
                                [row.partCode]: e.target.value
                              }));
                            }}
                            className="w-full px-1.5 py-0.5 bg-[#111111] border border-[#555555] text-slate-200 text-xs focus:border-cyan-500 focus:outline-none"
                            placeholder="ระบุหมายเหตุ..."
                            list="note-options"
                          />
                        ) : (
                          <span className="text-[10px] text-slate-300 line-clamp-1" title={row.stockNote}>
                            {row.stockNote || '-'}
                          </span>
                        )}
                      </td>

                      {/* Col 13: Actions (Edit & Delete) */}
                      <td className="py-1 px-2 text-center">
                        <div className="flex items-center justify-center gap-1.5">
                          <button
                            type="button"
                            onClick={() => handleOpenEditModalForRow(row)}
                            className="p-1 bg-[#111111] hover:bg-[#333333] text-[#00FF00] border border-[#555555] hover:border-[#00FF00] transition-colors cursor-pointer"
                            title="แก้ไขข้อมูลพาร์ท (Edit Part Details)"
                          >
                            <Edit3 className="w-3.5 h-3.5" />
                          </button>
                          
                          <button
                            type="button"
                            onClick={() => setDeleteTargetPart({
                              partCode: row.partCode,
                              partName: row.partName,
                              stage: row.stageName,
                              total: row.total
                            })}
                            className="p-1 bg-[#111111] hover:bg-[#2b000a] text-slate-400 hover:text-[#C40045] border border-[#555555] hover:border-[#C40045] transition-colors cursor-pointer"
                            title="ลบพาร์ทนี้ (Delete Part)"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>

                    </tr>
                  );
                })
              )}
            </tbody>

            {/* Table Footer: Line Summary Totals (Sticky bottom) */}
            <tfoot>
              <tr className="bg-[#333344] text-white font-bold border-t-2 border-[#666666] text-xs select-none">
                <td colSpan={3} className="py-1.5 px-2 text-right font-black uppercase tracking-wider text-slate-200 border-r border-[#555555]">
                  TOTAL ACTIVE TOOLING PER LINE (EA):
                </td>
                {LINE_COLUMNS.map(col => (
                  <td key={col.id} className="py-1.5 px-2 text-center border-r border-[#555555] font-mono font-black text-[#00FF00] text-xs">
                    {formatShots(lineSubTotals[col.id] || 0)}
                  </td>
                ))}
                <td className="py-1.5 px-2 text-center bg-[#282838] font-mono font-black text-[#FFCC00] text-xs border-r border-[#555555]">
                  {formatShots(grandTotalActiveTooling)}
                </td>
                <td className="py-1.5 px-2 text-center bg-[#282838] text-[10px] text-slate-400">
                  {filteredRows.length} พาร์ท
                </td>
              </tr>
            </tfoot>

          </table>
        </div>
      </div>

      {/* ======================================================== */}

      {/* 4. MODALS */}
      {/* ======================================================== */}
      
      <DeleteConfirmationModal
        isOpen={!!deleteTargetPart}
        onClose={() => setDeleteTargetPart(null)}
        onConfirm={handleConfirmDelete}
        title="ยืนยันการลบชิ้นส่วน (Delete Part)"
        itemName={deleteTargetPart ? `${deleteTargetPart.partName} (${deleteTargetPart.partCode})` : "" }
        itemDetails={deleteTargetPart ? `Stage: ${deleteTargetPart.stage} | Total Installed: ${deleteTargetPart.total} EA` : "" }
        warningText="การลบพาร์ทจากหน้านี้ จะเป็นการลบออกจากฐานข้อมูล Part Master ทั้งหมดอย่างถาวร"
      />

      {/* Stage Grouping Management Modal */}
      <StageManagementModal
        isOpen={isStageManagerOpen}
        onClose={() => setIsStageManagerOpen(false)}
        onSave={loadData}
      />
    </div>
  );
};

